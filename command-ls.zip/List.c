#include<stdio.h>
#include<stdlib.h>
#include<malloc.h>
#include<string.h>
#include"List.h"
#include"myls.h"

List* InitList(List *list){
    list->head.data = NULL;
    list->head.next = &list->head;
    list->head.prev = &list->head;
    list->first = &list->head;
    list->last = &list->head;
    return list;
}


void DeleteList(List *list, Todo todo){
    List_Node *pnode = list->first, *temp = NULL;
    while(pnode && pnode != &list->head){
        temp = pnode;
        pnode = pnode->next;
        if(todo) todo(temp->data);
        free(temp);
    }
}

//选择排序
void ListSortSelect(List *list, Cmp cmp){
    List_Node *temp;
    for(List_Node *pnode = list->first; pnode != &list->head; pnode = pnode->next){
        temp = pnode;
        for(List_Node *pnode2 = pnode->next; pnode2 != &list->head; pnode2 = pnode2->next)
            if(cmp(temp, pnode2)) temp = pnode2;
        ListNodeSwap(list, pnode, temp);
    }
}


int ListTraversal(List *list, Todo1 todo, void *data, int (*check)(void *data)){
    int i = 0;
    for(List_Node *pnode = list->first; pnode != &list->head; pnode = pnode->next, i++){
        if(check && check(pnode->data)) todo(pnode->data, *(int *)data);
        else todo(pnode->data, *(int *)data);
    }
        
    return i;
}

void ListInsertLast(List *list, List_Node *node){
    node->next = &list->head;
    list->last->next = node;

    node->prev = list->last;
    list->head.prev = node;

    list->last = node;
    if (list->first == &list->head) list->first = list->last;
}

void ListNodeSwap(List *list, List_Node *node1, List_Node *node2){
    /*
    List_Node *temp1 = node1->next, *temp2 = node1->prev;
    node1->next = node2->next;
    node1->prev = node2->prev;
    node2->prev->next = node1;
    node2->next->prev = node1;

    node2->next = temp1;
    node2->prev = temp2;
    temp1->prev = node2;
    temp2->next = node2;
    */
   void *p = node1->data;
   node1->data = node2->data;
   node2->data = p;
}



List_Node* ListDelete(List *list, Cmp cmp, List_Node *node){
    if(cmp){
        for(List_Node *pnode = list->first; pnode != &list->head; pnode = pnode->next)
            if(cmp(pnode, node)){
                if (list->first == pnode) list->first = pnode->next;
                if (list->last == pnode) list->last = pnode->prev;
                pnode->next->prev = pnode->prev;
                pnode->prev->next = pnode->next;
                node->next = NULL;
                node->prev = NULL;
                return pnode;
            }
    }
    else{
        if (list->first == node) list->first = node->next;
        if (list->last == node) list->last = node->prev;
        node->prev->next = node->next;
        node->next->prev = node->prev;
        node->next = NULL;
        node->prev = NULL;
        return node;
    }
    return NULL;
}