#ifndef LIST__H__
#define LIST__H__
#include<sys/stat.h>

typedef struct List_Node
{
    void *data;
    struct List_Node *prev;
    struct List_Node *next;
}List_Node;

typedef struct List
{
    List_Node head;
    List_Node *first;
    List_Node *last;
}List;

typedef int (*Cmp)(const List_Node *node1, const List_Node *node2);
typedef int (*Todo)(void *data);
typedef int (*Todo1)(void *data, int depth);

/*初始化链表*/
List* InitList(List *list);

/*
删除链表：
这个函数将释放所有list中的节点，对于list中节点的data将调用todo来释放，若todo为NULL则将直接调用free
注意：这个函数并不会直接释放list，它只会释放list的节点
*/
void DeleteList(List *list, Todo todo);

/*选择排序*/
void ListSortSelect(List *list, Cmp cmp);

/*
遍历链表：
使用todo对每个节点做相应的操作 
data: the arg to function todo
*/
int ListTraversal(List *list, Todo1 todo, void *data, int check(void *name));

/*将node节点加入list链表的尾部*/
void ListInsertLast(List *list, List_Node *node);

/*交换list链表中node1和node2的data*/
void ListNodeSwap(List *list, List_Node *node1, List_Node *node2);

#endif