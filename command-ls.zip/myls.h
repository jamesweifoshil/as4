#ifndef MYLS__H__
#define MYLS__H__
#include"List.h"

typedef struct Data{
    struct stat *buf;
    char name[];
}Data;

typedef int (*Func)(Data *data);

typedef struct command_t{
    char name;
    int tag;
    Func func;
}command_t;

int funcl(Data *data);
int funci(Data *data);
//int funcR(Data *data);

extern command_t commands[];
extern int commandCount;
extern char *wildcard;

int GetComdIndex(char comd);
int IsComdSet(char comd);

int dols(char *path, int depth);
int printMsg(void *data, int depth);

/*返回一个List_Node节点指针，将data设置为该节点的data*/
List_Node* MakeNode(char *name, struct stat *buf);

#endif