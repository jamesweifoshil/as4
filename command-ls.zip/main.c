#include<stdio.h>
#include<unistd.h>
#include<string.h>
#include<stdlib.h>
#include"myls.h"

//not use
int ArgParse(int argc, char *argv[]){
    int fileCount = 0;
    for(int i = 1; i < argc; i++){
        if(argv[i][0] == '-'){
            for(int k = 1; k < strlen(argv[i]); k++)
                for(int j = 0; j < commandCount; j++)
                    if(argv[i][k] == commands[j].name);
                        //SETBIT(commands[j].name, ilrbit);
        }
        else fileCount++;
    }
    return fileCount;
}

int main(int argc, char *argv[]){
    char buf[1024];
    getcwd(buf,1024);
	int opt;
	while((opt=getopt(argc,argv,"ilR"))!=-1){
        int i = 0;
        for(; i < commandCount; i++)
            if(opt == commands[i].name){
                commands[i].tag = 1;
                break;
            }
        if(i >= commandCount){
            printf("unknow option -%c", opt);
            exit(0);
        }
	}

    if(optind == argc) dols(".", 0);
    else for(int i = optind; i < argc; i++){
        chdir(buf);
        if(argv[i][0] == '*'){
            wildcard = argv[i];
            dols(".", 0);
            wildcard = NULL;
        }
        else dols(argv[i], 0);
    }
        
    return 0;
}