#include<stdio.h>
#include<sys/stat.h>
#include<stdlib.h>
#include<string.h>
#include<dirent.h>
#include<error.h>
#include<unistd.h>
#include<time.h>
#include<grp.h>
#include<pwd.h>
#include"List.h"
#include"myls.h"

command_t commands[] = {
    {'l', 0, funcl},
    {'i', 0, funci},
    {'R', 0, NULL}
};

int commandCount = sizeof(commands) / sizeof(command_t);

char *wildcard = NULL;

int GetComdIndex(char comd){ //get the index of the comd in the array commands
    for(int i = 0; i < commandCount; i++)
        if(commands[i].name == comd) return i;
    return -1;
}

int IsComdSet(char comd){ //check if the command comd is used 
    int index = GetComdIndex(comd);
    if(index == -1) return -1;
    return commands[index].tag;
}

int funci(Data *data){
    printf("%7lu ", data->buf->st_ino);//print the inode of the file
    return 0;
}

int funcl(Data *data){
    char str[11] = "----------"; //
	if(S_ISDIR(data->buf->st_mode)) str[0]='d';
	if(S_ISCHR(data->buf->st_mode)) str[0]='c';
	if(S_ISBLK(data->buf->st_mode)) str[0]='b';
    if(S_ISLNK(data->buf->st_mode)) str[0]='l';

	if(data->buf->st_mode&S_IRUSR)  str[1]='r';
	if(data->buf->st_mode&S_IWUSR)  str[2]='w';
	if(data->buf->st_mode&S_IXUSR)  str[3]='x';

	if(data->buf->st_mode&S_IRGRP)  str[4]='r';
   	if(data->buf->st_mode&S_IWGRP)  str[5]='w';
	if(data->buf->st_mode&S_IXGRP)  str[6]='x';

	if(data->buf->st_mode&S_IROTH)  str[7]='r';
	if(data->buf->st_mode&S_IWOTH)  str[8]='w';
	if(data->buf->st_mode&S_IXOTH)  str[9]='x';
    printf("%s", str);

    printf("%2ld ", data->buf->st_nlink);//print link count

    struct group *grp = getgrgid(data->buf->st_gid);//print username and group name
    struct passwd *pd = getpwuid(data->buf->st_uid);
    printf("%s %s", pd->pw_name ,grp->gr_name);

    printf(" %4ld ", data->buf->st_size);//print file size

    struct tm *ti = localtime(&data->buf->st_mtime);//print time of the last modification 
    char buf[20];
    strftime(buf, 20, "%b %d %G %H:%M", ti);
    printf("%s ", buf);
    return 0;
}


int printMsg(void *data, int depth){
    Data *pdata = (Data *)data;
    if(strcmp(pdata->name, ".") == 0 || strcmp(pdata->name, "..") == 0)//skip the name of . and ..
        return 0;

    for(int i = 0; i < 4 * depth; i++) printf("\n");

    int tag = 0, tag1 = 0;
    if(IsComdSet('i') == 1){
        commands[GetComdIndex('i')].func(data);
        tag = 1;
    }
    if(IsComdSet('l') == 1){
        commands[GetComdIndex('l')].func(data);
        tag = 1;
        tag1 = 1;
    }
    printf("%s", pdata->name);//print the name of the file

    if(tag1 && S_ISLNK(pdata->buf->st_mode)){//check if l option is used and the file is a link file then print the realname
        char realname[1024];
        int c = readlink(pdata->name, realname, 1024);
        realname[c] = '\0';
        printf(" -> %s", realname);
    }
    //if any option has been used the print the \n
    //if(tag || IsComdSet('R') == 1) printf(" ");
    if(tag && IsComdSet('i') == 1 && IsComdSet('l') == 1 && IsComdSet('R') == 1);

    if(tag && IsComdSet('i') == 1 && IsComdSet('R') == 1) printf(" ");

    if(tag && IsComdSet('l') == 1) printf("\n");
    
    if(tag && IsComdSet('l') == 1 && IsComdSet('R') == 1);
    
    else printf("  ");
}

List_Node* MakeNode(char *name, struct stat *buf){
    List_Node *pnode = (List_Node *)malloc(sizeof(List_Node));
    Data *data = (Data *)malloc(sizeof(Data) + sizeof(char) * (strlen(name) + 1));
    pnode->next = pnode->prev = NULL;
    strncpy(data->name, name, strlen(name) + 1);

    data->buf = (struct stat *)malloc(sizeof(struct stat));
    memcpy(data->buf, buf, sizeof(struct stat)); 
    pnode->data = data;
    return pnode;
}

static int deleteNode(void *data){
    Data *pdata = (Data *)data;
    free(pdata->buf);
    free(pdata);
    return 0;
}


static int cmp(const List_Node *node1, const List_Node *node2){
    Data *pdata1 = (Data *)node1->data;
    Data *pdata2 = (Data *)node2->data;
    return strcmp(pdata1->name, pdata2->name) > 0;
}

static int check(void *data){
    char *name = ((Data *)data)->name;
    int i = strlen(wildcard) - 1;
    int j = strlen(name) - 1;
    while(i >= 1 && j >= 0 && wildcard[i] == name[j])--i, --j;
    if(i >= 1) return 0;
    return 1;
}

int dols(char *path, int depth){
    struct stat buf;
    if(lstat(path, &buf) == -1){
        perror(path);
        return -1;
    }

    if(S_ISDIR(buf.st_mode) == 0){
        Data *data = (Data *)malloc(sizeof(Data) + (strlen(path) + 1));
        data->buf = &buf;
        strcpy(data->name,path);
        printMsg(data, depth);
        data->buf = NULL;
        free(data);
        return 0;
    }

    List files;
    InitList(&files);
    DIR *dp;
    struct dirent *entry;
    if((dp = opendir(path)) == NULL){
        perror("opendir");
        exit(0);
    }

    chdir(path);
	while((entry=readdir(dp))!=NULL){
		if(lstat(entry->d_name, &buf) == -1)
            perror("lstat");
        ListInsertLast(&files, MakeNode(entry->d_name, &buf));
	}
    closedir(dp);

    ListSortSelect(&files, cmp); //sort by name
    if(wildcard && strlen(wildcard) > 1)
        ListTraversal(&files, printMsg, &depth, check);
    else ListTraversal(&files, printMsg, &depth, NULL);
    printf("\n");

    if(IsComdSet('R') == 1){
        for(List_Node *pnode = files.first; pnode != &files.head; pnode = pnode->next){
            if(S_ISDIR(((Data *)pnode->data)->buf->st_mode)){
                if(strcmp(((Data *)pnode->data)->name, ".") == 0 || strcmp(((Data *)pnode->data)->name, "..") == 0)
                    continue;
                for(int i = 0; i < 4 * depth; i++) printf(" ");
                printf("%s:\n", ((Data *)pnode->data)->name);
                //chdir(((Data *)pnode->data)->name);
                dols(((Data *)pnode->data)->name, depth + 1);
				//chdir("..");
                //printf("\n");
            }
                
        }
    }
    DeleteList(&files, deleteNode);
	chdir("..");
    return 0;
}
