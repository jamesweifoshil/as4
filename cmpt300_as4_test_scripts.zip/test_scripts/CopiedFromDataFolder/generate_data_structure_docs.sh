#!/bin/bash

tree > inst_test_tree.txt
ls -liR > inst_test_listing.txt
